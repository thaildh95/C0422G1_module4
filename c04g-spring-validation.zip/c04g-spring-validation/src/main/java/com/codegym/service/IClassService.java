package com.codegym.service;

import com.codegym.model.ClassCG;

import java.util.List;

public interface IClassService {
    List<ClassCG> findAll();
}
